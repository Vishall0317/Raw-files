package com.foodorder.java.repository;

import java.util.List;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.foodorder.java.dto.OrderDetailsResponseDto;
import com.foodorder.java.entity.OrderDetails;

@Repository
public interface OrderDetailsRepository extends CrudRepository<OrderDetails, Integer> {
	List<OrderDetails> findByUserUserId(Integer userId);
}

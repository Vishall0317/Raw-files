package com.foodorder.java.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.foodorder.java.dto.OrderDetailsRequestDto;
import com.foodorder.java.dto.OrderDetailsResponseDto;
import com.foodorder.java.service.OrderDetailsService;

@RestController
public class OrderDetailsController {
	
	
	@Autowired
	OrderDetailsService orderDetailsService;
	
	@PostMapping("/orderDetails")
	public String placeOrder(@RequestBody OrderDetailsRequestDto orderDetailsRequestDto) {
	return orderDetailsService.placeOrder(orderDetailsRequestDto);
	}

	@GetMapping("/orderDetails/{userId}")
	public List<OrderDetailsResponseDto> showHistory(@PathVariable Integer userId){
	return orderDetailsService.showHistory(userId);
	}
}

package com.foodorder.java.entity;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

import javax.persistence.ElementCollection;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;

import lombok.Data;

@Data
@Entity
public class OrderDetails
{
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Integer orderDetailId;
	private Double totalPrice;
	private String orderNumber;
	
	@ManyToOne
	@JoinColumn(name="userId")
	private User user;
	
	@ElementCollection
	private List<FoodWithQuantity> foodList=new ArrayList<FoodWithQuantity>();
	private LocalDateTime date;
}

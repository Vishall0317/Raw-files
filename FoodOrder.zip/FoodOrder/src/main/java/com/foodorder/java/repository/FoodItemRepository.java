package com.foodorder.java.repository;

import java.util.List;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.foodorder.java.entity.FoodItem;

@Repository
public interface FoodItemRepository extends CrudRepository<FoodItem, Integer> {
	List<FoodItem> findByFoodNameContaining(String search);
}

package com.foodorder.java.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.foodorder.java.dto.FoodItemResponseDto;
import com.foodorder.java.service.FoodItemService;


@RestController
public class FoodItemController {

	@Autowired	
	FoodItemService foodItemService;
	
	@GetMapping("/foodItems")
	public List<FoodItemResponseDto> displayFoodItem() {
		List<FoodItemResponseDto> result=foodItemService.displayFoodItems();
		return result;
	}
	
	@GetMapping("/foodItems/search")
	public List<FoodItemResponseDto> searchFood(@RequestParam String search){
		return foodItemService.searchFood(search);
	}
}
	

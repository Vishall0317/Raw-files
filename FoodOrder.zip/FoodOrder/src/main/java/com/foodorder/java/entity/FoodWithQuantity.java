package com.foodorder.java.entity;

import javax.persistence.Embeddable;


import lombok.Data;

@Data
@Embeddable
public class FoodWithQuantity {
	
	private Integer foodItemId;
	private Integer quantity;

}

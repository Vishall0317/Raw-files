package com.foodorder.java.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.foodorder.java.dto.UserRequestDto;
import com.foodorder.java.service.UserService;

@RestController
public class UserController {
	@Autowired
	UserService userService;
	
	@PostMapping("/users")
	public String loginCheck(@RequestBody UserRequestDto userRequestDto) {
		String result=userService.loginCheck(userRequestDto);
		return result;
	}
}

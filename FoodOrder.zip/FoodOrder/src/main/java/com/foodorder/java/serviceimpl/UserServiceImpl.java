package com.foodorder.java.serviceimpl;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.foodorder.java.dto.UserRequestDto;
import com.foodorder.java.entity.User;
import com.foodorder.java.repository.UserRepository;
import com.foodorder.java.service.UserService;

@Service
public class UserServiceImpl implements UserService {
	@Autowired
	UserRepository userrepository;

	@Override
	public String loginCheck(UserRequestDto userRequestDto) {
		User user=userrepository.findByUsername(userRequestDto.getUsername());
		if(user==null) {
			return "user name not present";
		}
		String dbpassword=user.getPassword();
		String entrypass=userRequestDto.getPassword();
		if(dbpassword.equals(entrypass)) {
			return "login success";
		}
		return "login failed";
	}

}

package com.foodorder.java.serviceimpl;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.foodorder.java.dto.FoodItemResponseDto;
import com.foodorder.java.entity.FoodItem;
import com.foodorder.java.repository.FoodItemRepository;
import com.foodorder.java.service.FoodItemService;

@Service
public class FoodItemServiceImpl implements FoodItemService {

	@Autowired
	FoodItemRepository foodItemRepository;

	@Override
	public List<FoodItemResponseDto> displayFoodItems() {
		Iterator<FoodItem> it=foodItemRepository.findAll().iterator();
		List<FoodItemResponseDto> foodItemResponseDtos=new ArrayList<FoodItemResponseDto>();
		while(it.hasNext()) {
			FoodItem foodItem=it.next();
			FoodItemResponseDto foodItemResponseDto=new FoodItemResponseDto();
			BeanUtils.copyProperties(foodItem, foodItemResponseDto);
			foodItemResponseDtos.add(foodItemResponseDto);
		}
		return foodItemResponseDtos;
	}
	
	@Override
	public List<FoodItemResponseDto> searchFood(String search) {
	Iterator<FoodItem>foodIerator=foodItemRepository.findByFoodNameContaining(search).iterator();
	List<FoodItemResponseDto> list=new ArrayList<FoodItemResponseDto>();
	while(foodIerator.hasNext()) {
	FoodItem f=foodIerator.next();
	FoodItemResponseDto foodItemResponseDto=new FoodItemResponseDto();
	BeanUtils.copyProperties(f, foodItemResponseDto);
	list.add(foodItemResponseDto);
	}
	return list;
	}
	
}

package com.foodorder.java.service;

import java.util.List;

import com.foodorder.java.dto.FoodItemResponseDto;

public interface FoodItemService {

	List<FoodItemResponseDto> displayFoodItems();
	List<FoodItemResponseDto> searchFood(String search);

}

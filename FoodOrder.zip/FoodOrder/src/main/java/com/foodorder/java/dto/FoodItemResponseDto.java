package com.foodorder.java.dto;

import lombok.Data;

@Data  
public class FoodItemResponseDto {
	private Integer foodItemId;
	private String foodName;
	private Double price;
	private String foodType;
}

package com.foodorder.java.dto;

import lombok.Data;

@Data
public class UserRequestDto {
	private String username;
	private String password;
}

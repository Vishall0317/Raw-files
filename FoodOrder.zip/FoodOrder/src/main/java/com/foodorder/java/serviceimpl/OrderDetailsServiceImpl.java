package com.foodorder.java.serviceimpl;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.foodorder.java.dto.FoodWithQuantityRequestDto;
import com.foodorder.java.dto.OrderDetailsRequestDto;
import com.foodorder.java.dto.OrderDetailsResponseDto;
import com.foodorder.java.entity.FoodItem;
import com.foodorder.java.entity.FoodWithQuantity;
import com.foodorder.java.entity.OrderDetails;
import com.foodorder.java.entity.User;
import com.foodorder.java.repository.FoodItemRepository;
import com.foodorder.java.repository.OrderDetailsRepository;
import com.foodorder.java.repository.UserRepository;
import com.foodorder.java.service.OrderDetailsService;

@Service
public class OrderDetailsServiceImpl implements OrderDetailsService {

	@Autowired
	OrderDetailsRepository orderDetailsRepository;
	@Autowired
	UserRepository userRepository;
	@Autowired
	FoodItemRepository foodItemRepository;

	@Override
	public String placeOrder(OrderDetailsRequestDto orderDetailsRequestDto) {

		OrderDetails order = new OrderDetails();
		Integer id = orderDetailsRequestDto.getUserId();
		User user = userRepository.findById(id).get();
		order.setUser(user);

		order.setOrderNumber(System.currentTimeMillis() + "");
		// order.setDate(LocalDateTime.now());

		List<FoodWithQuantityRequestDto> eList = orderDetailsRequestDto.getList();
		// order.setFoodItems(list);
		List<FoodWithQuantity> list = order.getFoodList();
		Double totalCost = 0.0;
		for (FoodWithQuantityRequestDto fq : eList) {
			FoodItem foodItem = foodItemRepository.findById(fq.getFoodItemId()).get();
			Double itemCost = foodItem.getPrice() * fq.getQuantity();
			totalCost = totalCost + itemCost;
			FoodWithQuantity foodWithQuantity = new FoodWithQuantity();
			BeanUtils.copyProperties(fq, foodWithQuantity);
			list.add(foodWithQuantity);
		}
		order.setTotalPrice(totalCost);
		order.setDate(LocalDateTime.now());
		orderDetailsRepository.save(order);
		return "Order Placed Successfully !!";
	}

	@Override
	public List<OrderDetailsResponseDto> showHistory(Integer userId) {
		Iterator<OrderDetails>orderIterator=orderDetailsRepository.findByUserUserId(userId).iterator();
		List<OrderDetailsResponseDto> hList=new ArrayList<OrderDetailsResponseDto>();
		while(orderIterator.hasNext()) {
		OrderDetails or=orderIterator.next();
		OrderDetailsResponseDto orderDetailsResposeDto=new OrderDetailsResponseDto();
		BeanUtils.copyProperties(or, orderDetailsResposeDto);
		hList.add(orderDetailsResposeDto);
		}
		return hList;
	}
}

package com.foodorder.java.dto;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

import lombok.Data;

@Data
public class OrderDetailsResponseDto {
	private Integer orderDetailId;
	private String quantity;
	private Double totalPrice;
	private String orderNumber;
	private LocalDateTime date;
	private List<FoodWithQuantityRequestDto> foodlist=new ArrayList<FoodWithQuantityRequestDto>();
}

package com.foodorder.java.dto;

import lombok.Data;

@Data
public class FoodWithQuantityRequestDto {
private Integer foodItemId;
private Integer quantity;
}

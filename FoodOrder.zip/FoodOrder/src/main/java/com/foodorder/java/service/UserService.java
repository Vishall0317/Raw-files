package com.foodorder.java.service;

import com.foodorder.java.dto.UserRequestDto;

public interface UserService {

	String loginCheck(UserRequestDto userRequestDto);

}

package com.foodorder.java.service;

import java.util.List;

import com.foodorder.java.dto.OrderDetailsRequestDto;
import com.foodorder.java.dto.OrderDetailsResponseDto;

public interface OrderDetailsService {
	String placeOrder(OrderDetailsRequestDto orderDetailsRequestDto);

	List<OrderDetailsResponseDto> showHistory(Integer userId);
}

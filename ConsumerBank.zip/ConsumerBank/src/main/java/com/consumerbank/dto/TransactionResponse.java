package com.consumerbank.dto;

import java.sql.Date;

public interface TransactionResponse {

	private String transactionNumber;
	private double amount;
	private String transactionType;
	private Integer accountId;
	private Date transactiondate;
	private Integer senderAccountId;
	private Integer receiverAccountId;
}

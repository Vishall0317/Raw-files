package com.consumerbank.service.impl;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.consumerbank.dto.CustomerRequestDTO;
import com.consumerbank.dto.CustomerResponse;
import com.consumerbank.dto.CustomerResponseDTO;
import com.consumerbank.entity.Customer;
import com.consumerbank.repo.CustomerRepository;
import com.consumerbank.service.CustomerService;

@Service
public class CustomerServiceImpl implements CustomerService {

	@Autowired
	CustomerRepository customerRepository;
	
	@Override
	public boolean saveCustomerData(CustomerRequestDTO customerRequestDTO) {
	
		Customer customer=new Customer();
		
		BeanUtils.copyProperties(customerRequestDTO, customer);
		
		 Customer savedCustomer=customerRepository.save(customer);
		 if(savedCustomer !=null) return true;
		 return false;
	}

	@SuppressWarnings("rawtypes")
	@Override
	public List<CustomerResponseDTO> getCustomersDetails() {
		
		List<CustomerResponseDTO> customerResponseList=new ArrayList<>();
		Iterator iterator=customerRepository.findAll().iterator();
		
		while(iterator.hasNext()) {
			CustomerResponseDTO responseDTO=new CustomerResponseDTO();
			BeanUtils.copyProperties(iterator.next(), responseDTO);
			customerResponseList.add(responseDTO);
		}
		return customerResponseList;
	}

	@Override
	public CustomerResponseDTO getCustomersDetails(Integer customerId) {
	
		Customer customer=new Customer();
		CustomerResponseDTO customerResponseDTO=new CustomerResponseDTO();
		
		Optional<Customer> optionalCustomer=customerRepository.findById(customerId);
		
		if(optionalCustomer.isPresent()) {
			customer=optionalCustomer.get();
		}
		
		BeanUtils.copyProperties(customer, customerResponseDTO);
		return customerResponseDTO;
	}

	

//	@Override
//	public List<CustomerResponseDTO> getCustomersDetails(String name) {
//		List<CustomerResponseDTO> customerResponseList=new ArrayList<>();
//		List<Customer> customerList=customerRepository.findByCustomerName(name);
//		
//		for(Customer customer : customerList){
//			CustomerResponseDTO responseDTO=new CustomerResponseDTO();
//			BeanUtils.copyProperties(customer, responseDTO);
//			customerResponseList.add(responseDTO);
//		}
//		return customerResponseList;
//	}
	
	/*
	 * we write getCustomersDetails() in two ways.
	 */
	
	@Override
	public List<CustomerResponse> getCustomersDetails(String name) {
		
		return customerRepository.findByCustomerName(name);
	}

	@Override
	public List<CustomerResponseDTO> getContainingCustomersDetails(String name) {
		List<CustomerResponseDTO> customerResponseList=new ArrayList<>();
		List<Customer> customerList=customerRepository.findByCustomerNameContaining(name);
		
		for(Customer customer : customerList){
			CustomerResponseDTO responseDTO=new CustomerResponseDTO();
			BeanUtils.copyProperties(customer, responseDTO);
			customerResponseList.add(responseDTO);
		}
		return customerResponseList;
	}

	@Override
	public Customer updateCustomer(Customer customer) {
		Customer c=customerRepository.save(customer);
		return c;
	}

}

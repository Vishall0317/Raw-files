package com.consumerbank.service.impl.test;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import com.consumerbank.dto.AccountRequestDTO;
import com.consumerbank.entity.Account;
import com.consumerbank.repo.AccountRepository;
import com.consumerbank.service.impl.AccountServiceImpl;


@ExtendWith(MockitoExtension.class)
public class AccountServiceImplTest {

	@Mock
	AccountRepository accountRepository;
	
	@InjectMocks
	AccountServiceImpl accountServiceImpl;
	
	AccountRequestDTO accountRequestDTO;
	
	Account account;
	
	Account savedAccount;
	
	@BeforeEach
	public void setUp() {
		accountRequestDTO=new AccountRequestDTO();
		accountRequestDTO.setAccountNumber((long) 1234);
		accountRequestDTO.setBalance(1200);
		accountRequestDTO.setAccountType("SA");
		accountRequestDTO.setCustomerId(1);
		
//		account=new Account();
//		account.setAccountNumber((long) 1234);
//		account.setBalance(1200);
//		account.setAccountType("SA");
//		account.setCustomerId(1);
//		
//		savedAccount=new Account();
//		savedAccount.setAccountNumber((long) 1234);
//		savedAccount.setBalance(1200);
//		savedAccount.setAccountType("SA");
//		savedAccount.setCustomerId(1);
		
	}
	
	@Test
	public void saveAccountDataTest_Positive() {
		
		//context	
//    	when(accountRepository.save(any(Account.class))).thenReturn(savedAccount);
		
		when(accountRepository.save(any(Account.class))).thenAnswer(i->{
			Account account=i.getArgument(0);
			account.setAccountId(1);
			return account;
		});
	
		//event
		boolean result=accountServiceImpl.saveAccountData(accountRequestDTO);
		
		//outcome
		assertTrue(result);
		
	}
	
	@Test
	public void saveAccountDataTest_Negative() {
		
		//context
		when(accountRepository.save(any(Account.class))).thenReturn(savedAccount);
	
		//event
		boolean result=accountServiceImpl.saveAccountData(accountRequestDTO);
		
		//outcome
		assertFalse(result);
		
	}

}

package com.consumerbank.service.impl.test;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import com.consumerbank.dto.TransactionRequestDTO;
import com.consumerbank.entity.Transaction;
import com.consumerbank.repo.TransactionRepository;
import com.consumerbank.service.impl.TransactionServiceImpl;



@ExtendWith(MockitoExtension.class)
public class TransactionServiceImplTest {

	@Mock
	TransactionRepository transactionRepository;
	
	@InjectMocks
	TransactionServiceImpl transactionServiceImpl;
	
	TransactionRequestDTO transactionRequestDTO;
	
	Transaction transaction;
	
	Transaction savedTransaction;
	
	@BeforeEach
	public void setUp() {
		transactionRequestDTO=new TransactionRequestDTO();
		transactionRequestDTO.setTransactionNumber("tx123");
		transactionRequestDTO.setAmount(1200);
		transactionRequestDTO.setTransactionType("SA");
		transactionRequestDTO.setReceiverAccountId(2);
		transactionRequestDTO.setSenderAccountId(1);
		transactionRequestDTO.setTransactionNumber("tx123");
		//transactionController.setTransactiondate("2021-12-21");
	}
	
	@Test
	public void saveTransactionDataTest_Positive() {
		
		//context	
		when(transactionRepository.save(any(Transaction.class))).thenAnswer(i->{
			Transaction transaction=i.getArgument(0);
			transaction.setTransactionId(1);
			return transaction;
		});
	
		//event
		boolean result=transactionServiceImpl.saveTransactionData(transactionRequestDTO);
		
		//outcome
		assertTrue(result);
		
	}
	
	@Test
	public void saveTransactionDataTest_Negative() {
		
		//context
		when(transactionRepository.save(any(Transaction.class))).thenReturn(savedTransaction);
	
		//event
		boolean result=transactionServiceImpl.saveTransactionData(transactionRequestDTO);
		
		//outcome
		assertFalse(result);
		
	}

}

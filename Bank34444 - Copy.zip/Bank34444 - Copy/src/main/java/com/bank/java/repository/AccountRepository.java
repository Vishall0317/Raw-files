package com.bank.java.repository;

import java.util.List;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.bank.java.Dto.AccountResponseProj;
import com.bank.java.entity.Account;

@Repository
public interface AccountRepository extends CrudRepository<Account, Integer> {
	List<AccountResponseProj> findByCustomerCustomerId(Integer customerId);

}
package com.bank.java.Dto;

public interface CustomerResponseProj {

	Integer getCustomerId();

	String getCustomerName();

	String getPhoneNo();

	String getEmailId();

}

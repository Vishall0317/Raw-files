
package com.bank.java.exception;

public class MyCustomizedException extends RuntimeException {

	public MyCustomizedException(String message) {
		super(message);
	}

}
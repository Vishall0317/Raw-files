
package com.bank.java.Dto;

import javax.validation.constraints.Min;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;

public class TransactionRequestDto {
	@NotNull(message = "Sender AccountId cannot be null")
	private Integer fromAccountId;
	@NotNull(message = "Receiver AccountId cannot be null")
	private Integer toAccountId;
	@NotNull(message = "Amount cannot be null")
	@Min(value = 100, message = " Amount should not be less than 100")
	private Double amount;
	@NotEmpty(message="Transaction number cannot be empty")
	private String transactionNumber;

	public Integer getFromAccountId() {
		return fromAccountId;
	}

	public void setFromAccountId(Integer fromAccountId) {
		this.fromAccountId = fromAccountId;
	}

	public Integer getToAccountId() {
		return toAccountId;
	}

	public void setToAccountId(Integer toAccountId) {
		this.toAccountId = toAccountId;
	}

	public Double getAmount() {
		return amount;
	}

	public void setAmount(Double amount) {
		this.amount = amount;
	}

	public String getTransactionNumber() {
		return transactionNumber;
	}

	public void setTransactionNumber(String transactionNumber) {
		this.transactionNumber = transactionNumber;
	}
}

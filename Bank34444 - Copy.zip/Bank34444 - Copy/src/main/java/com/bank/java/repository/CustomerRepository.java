package com.bank.java.repository;

import java.util.List;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.bank.java.Dto.CustomerRequestDto;
import com.bank.java.Dto.CustomerResponseProj;
import com.bank.java.entity.Customer;

@Repository
public interface CustomerRepository extends CrudRepository<Customer, Integer> {
	List<CustomerResponseProj> findByCustomerNameContaining(String customerName);
	//Customer updateCustomerDetails(CustomerRequestDto customerRequestDto, Integer customerId);
}
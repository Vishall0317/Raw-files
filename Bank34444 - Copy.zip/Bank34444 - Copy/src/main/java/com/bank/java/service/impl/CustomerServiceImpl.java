
package com.bank.java.service.impl;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.bank.java.Dto.CustomerRequestDto;
import com.bank.java.Dto.CustomerResponseDto;
import com.bank.java.Dto.CustomerResponseProj;
import com.bank.java.entity.Customer;
import com.bank.java.exception.MyCustomizedException;
import com.bank.java.repository.CustomerRepository;
import com.bank.java.service.CustomerService;

@Service
public class CustomerServiceImpl implements CustomerService {
	@Autowired
	CustomerRepository customerRepository;

	@Override
	public String saveCustomer(CustomerRequestDto customerRequestDto) {
		Customer customer = new Customer();
		BeanUtils.copyProperties(customerRequestDto, customer);
		Customer savedCustomer =customerRepository.save(customer);
		if(savedCustomer!=null)return "Data saved successfully";
		return "Data save was unsuccessfull";
	}

	@Override
	public List<CustomerResponseDto> getCustomers() {
		List<CustomerResponseDto> customerResponseDtoList = new ArrayList<CustomerResponseDto>();
		Iterator<Customer> it = customerRepository.findAll().iterator();
		while (it.hasNext()) {
			CustomerResponseDto customerResponseDto = new CustomerResponseDto();
			BeanUtils.copyProperties(it.next(), customerResponseDto);
			customerResponseDtoList.add(customerResponseDto);
		}
		return customerResponseDtoList;
	}

	@Override
	public void deleteCustomer(Integer customerId) {
		Customer customer = customerRepository.findById(customerId).get();
		if (customer == null)
			throw new MyCustomizedException("Customer not found with customerId: " + customerId);
		customer = new Customer();
		customer.setCustomerId(customerId);
		customerRepository.delete(customer);
	}

	@Override
	public List<CustomerResponseProj> getCustomerbyName(String customerName) {
		List<CustomerResponseProj> customerResponseProjList = customerRepository
				.findByCustomerNameContaining(customerName);
		if (customerResponseProjList.isEmpty())
			throw new MyCustomizedException("Customer not found with given name: " + customerName);
		return customerResponseProjList;
	}

	public void updateCustomerDetails(CustomerRequestDto customerRequestDto, Integer customerId) {

		Customer customer = customerRepository.findById(customerId).get();
		BeanUtils.copyProperties(customerRequestDto, customer);
		customerRepository.save(customer);
	}
	}
	
	


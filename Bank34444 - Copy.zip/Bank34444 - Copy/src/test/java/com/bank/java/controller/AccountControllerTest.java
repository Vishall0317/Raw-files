package com.bank.java.controller;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.doNothing;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import com.bank.java.Dto.AccountRequestDto;
import com.bank.java.service.AccountService;



@ExtendWith(MockitoExtension.class)
public class AccountControllerTest {
	

	@Mock
	AccountService accountService;

	@InjectMocks
	AccountController accountController;
	AccountRequestDto accountRequestDto1;
	AccountRequestDto accountRequestDto;

	@BeforeEach
	public void setUp() {
		accountRequestDto = new AccountRequestDto();
		accountRequestDto.setAccountNumber(36843214433L);
		accountRequestDto.setAccountType("saving");
		accountRequestDto.setBalance(30000d);

	}

	@Test
	@DisplayName("Save account Data:Positive")
	public void saveAccountDataTest_Positive() {
//context
		doNothing().when(accountService).saveAccount(accountRequestDto);
//event
		ResponseEntity<String> result = accountController.saveAccount(accountRequestDto);

//outcome
		assertEquals("Account created succesfully", result.getBody());
		assertEquals(HttpStatus.ACCEPTED, result.getStatusCode());
	}


}

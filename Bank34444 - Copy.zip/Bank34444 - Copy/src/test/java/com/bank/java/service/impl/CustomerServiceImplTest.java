package com.bank.java.service.impl;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import com.bank.java.Dto.CustomerRequestDto;
import com.bank.java.entity.Customer;
import com.bank.java.repository.CustomerRepository;

@ExtendWith(MockitoExtension.class)
public class CustomerServiceImplTest {
	@Mock
	CustomerRepository customerRepository;

	@InjectMocks
	CustomerServiceImpl customerServiceImpl;

	CustomerRequestDto customerRequestDto;

	Customer customer;

	Customer savedCustomer;

	@BeforeEach
	public void setUp() {
		customerRequestDto = new CustomerRequestDto();
		customerRequestDto.setCustomerName("priya");
		customerRequestDto.setPhoneNo("8999880085");

		customer = new Customer(); // customer@1234
		customer.setCustomerName("priya");
		customer.setPhoneNo("8999880085");

		savedCustomer = new Customer();
		savedCustomer.setCustomerName("priya");
		savedCustomer.setPhoneNo("8999880085");

		savedCustomer.setCustomerId(1);
	}

	@Test
	public void saveCustomerDataTest_Positive() {
//context
		when(customerRepository.save(any(Customer.class))).thenAnswer(i -> {
			Customer customer = i.getArgument(0);
			customer.setCustomerId(1);
			return customer;
		});

//event
		customerServiceImpl.saveCustomer(customerRequestDto);

//outcome

	}

	@Test
	public void saveCustomerDataTest_Negative() {
//context
		when(customerRepository.save(any(Customer.class))).thenReturn(null);
//some_method(a, b, c)

//event
		customerServiceImpl.saveCustomer(customerRequestDto);

//outcome

		verify(customerRepository).save(any(Customer.class));
	}
}